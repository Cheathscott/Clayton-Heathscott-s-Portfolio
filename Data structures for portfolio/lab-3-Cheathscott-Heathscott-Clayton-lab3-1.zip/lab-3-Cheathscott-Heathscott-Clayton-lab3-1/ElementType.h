#ifndef ELEMENTT
#define ELEMENTT
/*-- ElementType.h ------------------------------------------------------
  This header file defines the data type being used the an ADT
-------------------------------------------------------------------------*/
typedef int ElementType;
#endif