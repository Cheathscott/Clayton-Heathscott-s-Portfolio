This is the code used for lab3.  
