This is an example used in Lab 1 and Project 2 for Data Structures.

Make sure you build, run, debug and understand this code!

Have fun!  Michelle Talley

